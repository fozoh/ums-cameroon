import React from 'react';

const DepartmentManagement = () => {
  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-4">Manage Departments</h2>
      <p>This is where HODs and Directors manage departments and courses.</p>
    </div>
  );
};

export default DepartmentManagement;